<?php
session_start();
require "db.php";

if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") {
    die("Access denied");
}

if (!isset($_GET["id"])) {
    die("Book ID missing.");
}

$id = $_GET["id"];

$stmt = $conn->prepare("DELETE FROM books WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo "Book deleted successfully! <a href='list_books.php'>Go back</a>";
} else {
    echo "Error deleting book: " . $stmt->error;
}
?>
