
<?php
session_start();
require "db.php";

$search = $_GET["search"] ?? "";


$isAdmin = isset($_SESSION["role"]) && $_SESSION["role"] === "admin";

$sql = "SELECT * FROM books WHERE title LIKE ? OR author LIKE ? OR published_year LIKE ?";
$stmt = $conn->prepare($sql);
$search_term = "%$search%";
$stmt->bind_param("sss", $search_term, $search_term, $search_term);
$stmt->execute();
$result = $stmt->get_result();


echo "<table border='1'>
        <tr>
            <th>Title</th>
            <th>Author</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Published Year</th>";
if ($isAdmin) {
    echo "<th>Actions</th>";
}
echo "</tr>";

while ($row = $result->fetch_assoc()) {
    echo "<tr>
            <td>{$row['title']}</td>
            <td>{$row['author']}</td>
            <td>Rs.{$row['price']}</td>
            <td>{$row['quantity']}</td>
            <td>{$row['published_year']}</td>";

    if ($isAdmin) {
        echo "<td>
                <a href=''>Edit</a> |
                <a href='delete_book.php?id={$row['id']}' onclick='return confirm(\"Are you sure you want to delete this book?\")'>Delete</a>
              </td>";
    }

    echo "</tr>";
}

echo "</table>";
?>
