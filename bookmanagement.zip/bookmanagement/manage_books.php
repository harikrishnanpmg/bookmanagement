<?php
session_start();
require "db.php";

if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") {
    die("Access denied");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST["title"];
    $author = $_POST["author"];
    $price = $_POST["price"];
    $quantity = $_POST["quantity"];
    $year = $_POST["year"];

    $stmt = $conn->prepare("INSERT INTO books (title, author, price, quantity, published_year) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssdis", $title, $author, $price, $quantity, $year);
    $stmt->execute();
    echo "Book added!";
}
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book management</title>
    <link rel="stylesheet" href="style.css">
</head>
 <h1> Book management</h1>
 <p><a href="logout.php">Log out</a> </p>
<form method="post">
    Title: <input type="text" name="title" required><br>
    Author: <input type="text" name="author" required><br>
    Price: <input type="number" step="0.01" name="price" required><br>
    Quantity: <input type="number" name="quantity" required><br>
    Published Year: <input type="number" name="year" required><br>
    <button type="submit">Add Book</button>
</form>
